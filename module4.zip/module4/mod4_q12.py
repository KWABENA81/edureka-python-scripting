from numpy import random

nums_4d = random.randint(59, size=(3, 3, 4, 4))
print('4Dim Array: \n', nums_4d)


# /home/sask/Documents/edureka-py/edureka-python-scripting/module4/venv/bin/python /home/sask/Documents/edureka-py/edureka-python-scripting/module4/mod4_q12.py
# 4Dim Array:
#  [[[[58 19 30 48]
#    [ 9  5 49 48]
#    [53  7 34  5]
#    [ 4 33 25 57]]
#
#   [[16  9 55 53]
#    [19 19 23 45]
#    [36 14 24  8]
#    [58  7  5 25]]
#
#   [[44 14 39 45]
#    [19  4 51 26]
#    [21 41  7 57]
#    [26 51 17  3]]]
#
#
#  [[[41  1  3  4]
#    [11 30 14  1]
#    [32 20  0 50]
#    [ 4 55  3 45]]
#
#   [[15 58 27 34]
#    [15 55 43 26]
#    [27 14 50  6]
#    [52 44 32 37]]
#
#   [[31 31 50 14]
#    [50 39 25 20]
#    [33 37 54 50]
#    [19 25 44 52]]]
#
#
#  [[[57 10 40 39]
#    [44 49 10  9]
#    [16 28 53 13]
#    [26 26 47 37]]
#
#   [[49  2 30 56]
#    [52 13 41 51]
#    [25 44 26  7]
#    [19 11 15  3]]
#
#   [[49 29 19 22]
#    [29 57 38 52]
#    [58 20 52 17]
#    [23 11 25  6]]]]
#
# Process finished with exit code 0