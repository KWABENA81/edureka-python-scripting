nums = set([1, 1, 2, 3, 3, 3, 4, 4])
print(len(nums))


#       OUTPUT
# /home/sasops/Documents/ops/edureka-python-scripting/python_edureka/bin/python /home/sasops/PycharmProjects/python_edureka/DS_mod2/Q1.py
# 4
#
# Process finished with exit code 0
