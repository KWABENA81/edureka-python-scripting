d = {"john" : 40, "peter" :45}
print(list(d.keys()))


#       OUTPUT
# /home/sasops/Documents/ops/edureka-python-scripting/python_edureka/bin/python /home/sasops/PycharmProjects/python_edureka/DS_mod2/Q2.py
# ['john', 'peter']
#
# Process finished with exit code 0

