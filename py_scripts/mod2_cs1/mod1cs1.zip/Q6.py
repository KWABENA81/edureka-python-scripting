import re
from collections import Counter

print('word: ', ''.join(reversed(input("Enter string: "))))


#   OUTPUT
# # /home/sasops/Documents/ops/edureka-python-scripting/python_edureka/bin/python /home/sasops/PycharmProjects/python_edureka/DS_mod2/Q6.py
# /home/sasops/Documents/ops/edureka-python-scripting/python_edureka/bin/python /home/sasops/PycharmProjects/python_edureka/DS_mod2/Q7.py
# Enter string: hello have a strong day
# word:  yad gnorts a evah olleh
#
# Process finished with exit code 0
