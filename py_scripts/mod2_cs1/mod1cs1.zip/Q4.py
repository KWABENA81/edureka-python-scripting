a = [4, 7, 3, 2, 5, 9]
for b in a:
    print(b)

# /home/sasops/Documents/ops/edureka-python-scripting/python_edureka/bin/python /home/sasops/PycharmProjects/python_edureka/DS_mod2/Q4.py
# 4
# 7
# 3
# 2
# 5
# 9
#
# Process finished with exit code 0