def print_hi(name):
    var = input("enter word sequence:")
    var2 = sorted(var.split())
    for x in var2:
        print(x)


if __name__ == '__main__':
    print_hi('Solomon S A')

# See PyCharm help at https://www.jetbrain